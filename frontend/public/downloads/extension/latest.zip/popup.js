"use strict";(()=>{var g="http://localhost:8000/api/v1";async function m(){let t=(await chrome.storage.local.get("api_base_url")).api_base_url;if(!t||typeof t!="string")return g;try{let s=new URL(t);return s.protocol!=="http:"&&s.protocol!=="https:"||!s.pathname.startsWith("/api/v1")?g:t.replace(/\/+$/,"")}catch{return g}}var v=class{async batchValidate(t,s){try{let a=await m(),i=await fetch(`${a}/extensions/batch-validate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({license_key:t,prompts_count:s})});if(!i.ok)throw new Error(`HTTP ${i.status}: ${i.statusText}`);let o=await i.json();return o.allowed&&await this.cachePermission(o),o}catch(a){return console.error("Batch validation failed:",a),await this.handleAPIError(a)}}async deductCredit(t,s){try{let a=await m(),i=await fetch(`${a}/extensions/deduct-credit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({session_token:t,prompt_index:s})});if(!i.ok){let c=`HTTP ${i.status}`;try{let p=await i.json();c=p.detail||p.message||c}catch{c=`HTTP ${i.status}: ${i.statusText}`}throw new Error(c)}let o=await i.json();if(!o.success)throw new Error(o.message||"Server returned success: false");return o}catch(a){throw console.error("Deduct credit failed:",a),a}}async finalizeSession(t,s,a=0,i){try{let o=await m(),c=await fetch(`${o}/extensions/finalize-session`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({session_token:t,prompts_sent:s,errors_count:a,duration_seconds:i})});if(!c.ok)throw new Error(`HTTP ${c.status}`);return await c.json()}catch(o){return console.error("Finalize session failed:",o),{success:!1,message:"Failed to finalize session",credits_used:s,credits_remaining:0}}}async healthCheck(){try{let t=await m(),s=new AbortController,a=setTimeout(()=>s.abort(),2e3),i=await fetch(`${t}/extensions/health`,{method:"GET",signal:s.signal});return clearTimeout(a),i.ok}catch(t){return console.warn("Health check failed:",t),!1}}async getBalance(t){let s=await m(),a=await fetch(`${s}/extensions/balance`,{method:"GET",headers:{"X-License-Key":t}});if(!a.ok)throw new Error(`HTTP ${a.status}`);return await a.json()}async bindLicense(t,s,a){let i=await m();return await(await fetch(`${i}/extensions/bind-license`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({license_key:t,fingerprint:s,device_info:a})})).json()}async handleAPIError(t){console.warn("\u26A0\uFE0F API unavailable, attempting graceful degradation...");let s=await this.getCachedPermission();if(s&&Date.now()<s.cached_at+s.ttl_ms)return console.warn("\u2705 Using cached permission (valid for "+Math.round((s.cached_at+s.ttl_ms-Date.now())/1e3)+"s)"),{allowed:!0,session_token:s.session_token,config:s.config,message:"Working in offline mode (cached)"};throw new Error("API unavailable and cache expired. Please check your internet connection.")}async cachePermission(t){let s={...t,cached_at:Date.now(),ttl_ms:3e5};await chrome.storage.local.set({cached_permission:s})}async getCachedPermission(){return(await chrome.storage.local.get("cached_permission")).cached_permission||null}},_=new v;function L(n){if(!n||typeof n!="string")return"";let t=n.trim();if(t=t.replace(/^\d+\.\s*/,""),t=t.replace(/\s+/g," ").trim(),!t.startsWith("/imagine")){let s=t.toLowerCase().indexOf("/imagine");s>0?t=t.substring(s):(console.warn("Prompt does not contain /imagine, adding prefix:",t.substring(0,50)),t.startsWith("/imagine prompt:")||(t="/imagine prompt: "+t))}return t}function f(n){return Array.isArray(n)?n.map(t=>L(t)).filter(t=>t.length>0):[]}function h(n){if(!n||typeof n!="string")return[];let t=n.split(`
`),s=[],a="";for(let i of t){let o=i.trim();if(o===""&&a.trim()!==""){s.push(a.trim()),a="";continue}o.match(/^\d+\./)||o.startsWith("/imagine")?(a.trim()!==""&&s.push(a.trim()),a=o):o!==""&&(a?a+=" "+o:a=o)}return a.trim()!==""&&s.push(a.trim()),s}var e={licenseKey:"",prompts:[],isRunning:!1,currentPrompt:0,totalPrompts:0,status:"Ready",balance:null,error:null,delayMin:30,delayMax:60,keyValidationStatus:null,keyValidationMessage:null},l={discordStatus:null};document.addEventListener("DOMContentLoaded",async()=>{await B(),r(),x();try{let n=await chrome.runtime.sendMessage({type:"QUEUE_STATUS_REQUEST"});if(n?.ok&&n.state){let t=n.state;e.totalPrompts=Array.isArray(t.prompts)?t.prompts.length:0,e.currentPrompt=typeof t.current_index=="number"?t.current_index:0,e.isRunning=t.status==="sending"||t.status==="validating",e.status=$(t),e.error=t.last_error||null,r()}}catch{}});async function B(){let n=await chrome.storage.local.get(["license_key","prompts","delay_min","delay_max"]);n.license_key&&(e.licenseKey=n.license_key),n.prompts&&(e.prompts=n.prompts),n.delay_min!==void 0&&(e.delayMin=n.delay_min),n.delay_max!==void 0&&(e.delayMax=n.delay_max)}async function u(){await chrome.storage.local.set({license_key:e.licenseKey,prompts:e.prompts,delay_min:e.delayMin,delay_max:e.delayMax})}function x(){let n=document.getElementById("license-key"),t=document.getElementById("prompts"),s=document.getElementById("delay-min"),a=document.getElementById("delay-max"),i=document.getElementById("start-btn"),o=document.getElementById("pause-btn"),c=document.getElementById("stop-btn"),p=document.getElementById("apply-key-btn");n&&n.addEventListener("input",d=>{e.licenseKey=d.target.value,u(),e.keyValidationStatus=null,e.keyValidationMessage=null,r()}),t&&t.addEventListener("input",d=>{let y=d.target.value;e.prompts=y.split(`
`),u(),r()}),s&&s.addEventListener("input",d=>{let y=parseInt(d.target.value)||0;e.delayMin=Math.max(1,y),e.delayMin>e.delayMax&&(e.delayMax=e.delayMin,a&&(a.value=e.delayMax.toString())),u()}),a&&a.addEventListener("input",d=>{let y=parseInt(d.target.value)||0;e.delayMax=Math.max(e.delayMin,y),u()}),i&&i.addEventListener("click",C),o&&o.addEventListener("click",H),c&&c.addEventListener("click",j),p&&p.addEventListener("click",A);let w=document.getElementById("format-prompts-btn");w&&w.addEventListener("click",V);let P=document.getElementById("auto-search-btn");P&&P.addEventListener("click",R);let S=document.getElementById("manual-search-btn");S&&S.addEventListener("click",I);let T=document.getElementById("reset-settings-btn");T&&T.addEventListener("click",U)}async function R(){l.discordStatus="\u0410\u0432\u0442\u043E-\u043F\u043E\u0438\u0441\u043A...",r();try{let[n]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!n.id||!n.url?.includes("discord.com")){l.discordStatus="\u274C \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Discord",r();return}await k(n.id),await chrome.tabs.sendMessage(n.id,{type:"TEST_INPUT",picker:!1}),M()}catch(n){l.discordStatus=`\u274C \u041E\u0448\u0438\u0431\u043A\u0430: ${n.message}`,r()}}async function I(){l.discordStatus="\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u044D\u043B\u0435\u043C\u0435\u043D\u0442...",r();try{let[n]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!n.id||!n.url?.includes("discord.com")){l.discordStatus="\u274C \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0432\u043A\u043B\u0430\u0434\u043A\u0443 Discord",r();return}await k(n.id),await chrome.tabs.sendMessage(n.id,{type:"TEST_INPUT",picker:!0}),M()}catch(n){l.discordStatus=`\u274C \u041E\u0448\u0438\u0431\u043A\u0430: ${n.message}`,r()}}async function k(n){try{await chrome.tabs.sendMessage(n,{type:"PING"})}catch{await chrome.scripting.executeScript({target:{tabId:n},files:["content.js"]}),await new Promise(t=>setTimeout(t,500))}}function M(){let n=t=>{t.type==="TEST_RESULT"&&(chrome.runtime.onMessage.removeListener(n),t.found?t.selector?l.discordStatus=`\u2705 \u041D\u0430\u0439\u0434\u0435\u043D\u043E! \u0421\u0435\u043B\u0435\u043A\u0442\u043E\u0440: ${t.selector}`:l.discordStatus="\u2705 \u041F\u043E\u043B\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u0438 \u043F\u043E\u0434\u0441\u0432\u0435\u0447\u0435\u043D\u043E":l.discordStatus=t.error?`\u274C \u041E\u0448\u0438\u0431\u043A\u0430: ${t.error}`:t.message||"\u274C \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043D\u0430\u0439\u0442\u0438 \u043F\u043E\u043B\u0435",r(),setTimeout(()=>{l.discordStatus=null,r()},8e3))};chrome.runtime.onMessage.addListener(n)}async function U(){confirm("\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0432\u0441\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438?")&&(await chrome.storage.local.remove(["last_successful_selector"]),u(),r(),b("\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0441\u0431\u0440\u043E\u0448\u0435\u043D\u044B"))}function V(){let n=document.getElementById("prompts");if(!n)return;let t=n.value;if(!t.trim()){b("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u0440\u043E\u043C\u043F\u0442\u044B \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F");return}let s=h(t),a=f(s);if(a.length===0){b("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u0432\u0430\u043B\u0438\u0434\u043D\u044B\u0445 \u043F\u0440\u043E\u043C\u043F\u0442\u043E\u0432");return}let i=a.map((o,c)=>`${c+1}. ${o}`).join(`

`);n.value=i,e.prompts=i.split(`
`),u(),r(),b(`\u2713 \u041E\u0442\u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043E ${a.length} \u043F\u0440\u043E\u043C\u043F\u0442\u043E\u0432`)}async function A(){let n=e.licenseKey.trim();if(!n){e.keyValidationStatus="invalid",e.keyValidationMessage="\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u043E\u043D\u043D\u044B\u0439 \u043A\u043B\u044E\u0447",r();return}if(!n.startsWith("sk_live_")){e.keyValidationStatus="invalid",e.keyValidationMessage="\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u043A\u043B\u044E\u0447\u0430. \u041A\u043B\u044E\u0447 \u0434\u043E\u043B\u0436\u0435\u043D \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 sk_live_",e.balance=null,r();return}e.keyValidationStatus="checking",e.keyValidationMessage="\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043A\u043B\u044E\u0447\u0430...",e.balance=null,r();try{let t=await _.getBalance(n);e.keyValidationStatus="valid",e.balance=t.balance,e.keyValidationMessage=`\u2705 \u041A\u043B\u044E\u0447 \u0432\u0430\u043B\u0438\u0434\u0435\u043D. \u0411\u0430\u043B\u0430\u043D\u0441: ${t.balance} \u043A\u0440\u0435\u0434\u0438\u0442\u043E\u0432`,await u()}catch(t){e.keyValidationStatus="invalid",e.balance=null;let s=t.message||"Unknown error";s.includes("401")||s.includes("Invalid")?e.keyValidationMessage="\u274C \u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0438\u043B\u0438 \u043D\u0435\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u043A\u043B\u044E\u0447":s.includes("Network")||s.includes("fetch")?e.keyValidationMessage="\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u043A \u0441\u0435\u0440\u0432\u0435\u0440\u0443. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442":e.keyValidationMessage=`\u274C \u041E\u0448\u0438\u0431\u043A\u0430: ${s}`}r()}async function C(){if(!e.licenseKey){E("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u043E\u043D\u043D\u044B\u0439 \u043A\u043B\u044E\u0447");return}if(e.prompts.length===0){E("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0445\u043E\u0442\u044F \u0431\u044B \u043E\u0434\u0438\u043D \u043F\u0440\u043E\u043C\u043F\u0442");return}let n=e.prompts.join(`
`),t=h(n),s=f(t);if(s.length===0){E("\u041F\u043E\u0441\u043B\u0435 \u043E\u0447\u0438\u0441\u0442\u043A\u0438 \u043D\u0435 \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0432\u0430\u043B\u0438\u0434\u043D\u044B\u0445 \u043F\u0440\u043E\u043C\u043F\u0442\u043E\u0432");return}console.log(`\u{1F4DD} \u041E\u0447\u0438\u0449\u0435\u043D\u043E \u043F\u0440\u043E\u043C\u043F\u0442\u043E\u0432: ${e.prompts.length} \u2192 ${s.length}`),e.isRunning=!0,e.error=null,e.currentPrompt=0,e.totalPrompts=s.length,e.status="Starting...",r();try{let a=await chrome.runtime.sendMessage({type:"QUEUE_START",prompts:s,license_key:e.licenseKey||"",delay_min_sec:e.delayMin,delay_max_sec:e.delayMax});if(!a?.ok)throw new Error(a?.error||"\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043E\u0447\u0435\u0440\u0435\u0434\u044C");e.status="\u2705 \u041E\u0447\u0435\u0440\u0435\u0434\u044C \u0437\u0430\u043F\u0443\u0449\u0435\u043D\u0430"}catch(a){e.error=a.message||"Unknown error",e.status="\u041E\u0448\u0438\u0431\u043A\u0430"}finally{r()}}function H(){chrome.runtime.sendMessage({type:"QUEUE_PAUSE"}).catch(()=>{}),e.status="Paused",e.isRunning=!1,r()}function j(){chrome.runtime.sendMessage({type:"QUEUE_STOP"}).catch(()=>{}),e.isRunning=!1,e.status="Stopped",r()}async function K(){if(!e.licenseKey){e.balance=null,r();return}try{let n=await _.getBalance(e.licenseKey);e.balance=n.balance,r()}catch(n){console.error("Failed to update balance:",n)}}function r(){let n=document.getElementById("app");if(!n)return;let t=e.totalPrompts>0?Math.round(e.currentPrompt/e.totalPrompts*100):0,s=e.prompts.join(`
`),a=h(s),i=f(a).length;n.innerHTML=`
    <div class="header">
      <h1>Midjourney Auto</h1>
      ${e.balance!==null?`<div class="balance">\u0411\u0430\u043B\u0430\u043D\u0441: ${e.balance} \u043A\u0440\u0435\u0434\u0438\u0442\u043E\u0432</div>`:""}
    </div>
    
    <div class="section">
      <label for="license-key">\u041B\u0438\u0446\u0435\u043D\u0437\u0438\u043E\u043D\u043D\u044B\u0439 \u043A\u043B\u044E\u0447</label>
      <div class="input-group">
        <input 
          type="text" 
          id="license-key" 
          placeholder="sk_live_..." 
          value="${e.licenseKey}"
          ${e.isRunning?"disabled":""}
        />
        <button id="apply-key-btn" class="btn-secondary" ${e.isRunning||e.keyValidationStatus==="checking"?"disabled":""} title="\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0438 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043B\u044E\u0447">
          ${e.keyValidationStatus==="checking"?"\u23F3 \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430...":"\u2713 \u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C"}
        </button>
      </div>
      ${e.keyValidationMessage?`
        <div class="key-validation-message ${e.keyValidationStatus==="valid"?"key-validation-success":e.keyValidationStatus==="invalid"?"key-validation-error":""}">
          ${e.keyValidationMessage}
        </div>
      `:""}
    </div>
    
    <div class="section">
      <label for="prompts">\u041F\u0440\u043E\u043C\u043F\u0442\u044B (\u043F\u043E \u043E\u0434\u043D\u043E\u043C\u0443 \u043D\u0430 \u0441\u0442\u0440\u043E\u043A\u0443)</label>
      <textarea 
        id="prompts" 
        rows="8" 
        placeholder="\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u0440\u043E\u043C\u043F\u0442\u044B, \u043A\u0430\u0436\u0434\u044B\u0439 \u0441 \u043D\u043E\u0432\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438..."
        ${e.isRunning?"disabled":""}
      >${e.prompts.join(`
`)}</textarea>
      <div class="prompts-info">
        <span class="prompts-count">${i} \u043F\u0440\u043E\u043C\u043F\u0442\u043E\u0432</span>
        <button 
          id="format-prompts-btn" 
          class="btn-format"
          ${e.isRunning?"disabled":""}
          title="\u041E\u0442\u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438 \u043F\u043E\u0434\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0440\u043E\u043C\u043F\u0442\u044B"
        >
          \u2728 \u0424\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C
        </button>
      </div>
    </div>
    
    <div class="section">
      <div class="button-row">
        <button 
          id="auto-search-btn" 
          class="btn-secondary"
          ${e.isRunning?"disabled":""}
          title="\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043D\u0430\u0439\u0442\u0438 \u043F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 Discord"
        >
          \u{1F916} \u0410\u0432\u0442\u043E-\u043F\u043E\u0438\u0441\u043A
        </button>
        <button 
          id="manual-search-btn" 
          class="btn-secondary"
          ${e.isRunning?"disabled":""}
          title="\u0412\u0440\u0443\u0447\u043D\u0443\u044E \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u043F\u043E\u043B\u0435 \u0432\u0432\u043E\u0434\u0430 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435"
        >
          \u{1F3AF} \u0420\u0443\u0447\u043D\u043E\u0439-\u043F\u043E\u0438\u0441\u043A
        </button>
      </div>
      ${l.discordStatus?`
        <div class="discord-status ${l.discordStatus.includes("\u2705")?"success":l.discordStatus.includes("\u274C")?"error":""}">${l.discordStatus}</div>
      `:""}
    </div>
    
    <div class="section">
      <label>\u0418\u043D\u0442\u0435\u0440\u0432\u0430\u043B \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 (\u0441\u0435\u043A\u0443\u043D\u0434\u044B)</label>
      <div class="delay-range">
        <div class="delay-input-group">
          <label for="delay-min" class="delay-label">\u041E\u0442:</label>
          <input 
            type="number" 
            id="delay-min" 
            min="1" 
            max="600" 
            value="${e.delayMin}"
            ${e.isRunning?"disabled":""}
            class="delay-input"
          />
          <span class="delay-unit">\u0441\u0435\u043A</span>
        </div>
        <div class="delay-separator">\u2014</div>
        <div class="delay-input-group">
          <label for="delay-max" class="delay-label">\u0414\u043E:</label>
          <input 
            type="number" 
            id="delay-max" 
            min="1" 
            max="600" 
            value="${e.delayMax}"
            ${e.isRunning?"disabled":""}
            class="delay-input"
          />
          <span class="delay-unit">\u0441\u0435\u043A</span>
        </div>
      </div>
      <div class="delay-hint">\u0421\u043B\u0443\u0447\u0430\u0439\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0432 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0435 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u043F\u0440\u043E\u043C\u043F\u0442\u0430</div>
    </div>
    
    <div class="section">
      <div class="status-bar">
        <div class="status">${e.status}</div>
        ${e.totalPrompts>0?`
          <div class="progress">
            <div class="progress-bar" style="width: ${t}%"></div>
          </div>
          <div class="progress-text">${e.currentPrompt}/${e.totalPrompts}</div>
        `:""}
      </div>
    </div>
    
    ${e.error?`
      <div class="error-message">
        \u274C ${e.error}
      </div>
    `:""}
    
    <div class="section settings-section">
      <h3>\u2699\uFE0F \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438</h3>
      
      <button 
        id="reset-settings-btn" 
        class="btn-secondary"
        style="margin-top: 8px; width: 100%;"
        ${e.isRunning?"disabled":""}
      >
        \u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438
      </button>
    </div>
    
    <div class="section actions">
      <button 
        id="start-btn" 
        class="btn-primary"
        ${e.isRunning?"disabled":""}
      >
        \u25B6\uFE0F Start
      </button>
      <button 
        id="pause-btn" 
        class="btn-secondary"
        ${e.isRunning?"":"disabled"}
      >
        \u23F8\uFE0F Pause
      </button>
      <button 
        id="stop-btn" 
        class="btn-danger"
        ${e.isRunning?"":"disabled"}
      >
        \u23F9\uFE0F Stop
      </button>
    </div>
  `,x()}function b(n){let t=document.createElement("div");t.className="notification",t.textContent=n,document.body.appendChild(t),setTimeout(()=>{t.remove()},2e3)}function E(n){e.error=n,r(),setTimeout(()=>{e.error=null,r()},5e3)}chrome.runtime.onMessage.addListener(n=>{if(n.type==="QUEUE_STATE"&&n.state){let t=n.state;e.totalPrompts=Array.isArray(t.prompts)?t.prompts.length:e.totalPrompts,e.currentPrompt=typeof t.current_index=="number"?t.current_index:e.currentPrompt,e.isRunning=t.status==="sending"||t.status==="validating",e.status=$(t),e.error=t.last_error||null,r(),t.status==="done"&&K().catch(()=>{})}});function $(n){let t=n?.status,s=typeof n?.current_index=="number"?n.current_index:0,a=Array.isArray(n?.prompts)?n.prompts.length:0,i=n?.last_error?` (\u274C ${n.last_error})`:"";return t==="idle"?"Ready":t==="validating"?"\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0438...":t==="sending"?`\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430... ${s}/${a}`:t==="paused"?`\u041F\u0430\u0443\u0437\u0430 ${s}/${a}`:t==="stopped"?`\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E ${s}/${a}`:t==="done"?`\u2705 \u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E: ${a}/${a}`:t==="error"?`\u041E\u0448\u0438\u0431\u043A\u0430${i}`:"Ready"}})();
